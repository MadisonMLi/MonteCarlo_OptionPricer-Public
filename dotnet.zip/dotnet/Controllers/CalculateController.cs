using MC_CV;
using Microsoft.AspNetCore.Mvc;
// using System;
// using System.Web.Http;
namespace dotnet.Controllers;



[ApiController]
[Route("[controller]")]
public class CalculateController : ControllerBase
{

    // public class OptionInputs
    // {
    //     internal Simulator sim;

    //     public string type { get; set; }
    //     // public double Tenor { get; set; }
    //     // public double Rate { get; set; }
    //     public double Strike { get; set; }
    //     public double S { get; set; }
    //     public double T { get; set; }
    //     public double r { get; set; }
    //     public double sigma { get; set; }
    //     // public long Simulator { get; set; }

    //     public long steps { get; set; } //N
    //     public int trails { get; set; } //M
    //     public bool Anti { get; set; }
    //     public bool CV { get; set; }

    //     public bool Multi { get; set; }

    //     public bool Iscall { get; set; } // Call or Put
        
    //     public double rebate { get; set; }

    //     public double bar {get; set;}
       
    //     public bool UpOut { get; set; }
    //     public bool UpIn { get; set; }
    //     public bool DownOut { get; set; }
    //     public bool DownIn { get; set; }
    // }


    public class OutputResults
    {
        internal double[,] price;

        public double result { get; set;}
        public double SE { get; set;}
        public double delta { get; set;}
        public double gamma { get; set;}
        public double vega { get; set;}
        public double theta { get; set;}
        public double rho { get; set;}
    }

    [HttpPost]
    public ActionResult<OutputResults> Post([FromBody] OptionInputs i)
    {
        Simulator sim = new Simulator()
        {
            M = (int)i.trails,
            N = (int)i.steps,
            Anti = i.Anti,
            CV = i.CV,
            Multi = i.Multi
        };
        double[,] sig = sim.Norm_polar();


        YieldPoint yp = new YieldPoint()
        {
            Rate = i.r
        } ;

        UnderlyingPrice udl = new UnderlyingPrice()
            {
                Price = i.S
            };

        double [,] price = new double[1,2];
        double delta1 = 0;
        double gamma1 = 0;
        double rho1 = 0;
        double vega1 = 0;
        double theta1 =0;
        
       // double[,] CalResult = option.GetPrice(S, r, sigma, T, sig, sim);
       
        if(i.type == "European" )
        {
            European eur = new European()
            {
                UnderlyingPrice = udl,
                YieldPoint = yp,
                Strike = i.Strike,
                T = i.T,
                Sigma = i.sigma,
                Iscall = i.Iscall,
                    
            };


            price = eur.GetPrice(eur.UnderlyingPrice.Price, eur.YieldPoint.Rate, eur.Sigma, eur.T, sig, sim);
            
            delta1 = eur.GetDelta(sig, sim);
            gamma1 = eur.GetGamma(sig, sim);
            rho1 = eur.GetRho(sig, sim);
            vega1 = eur.GetVega(sig, sim);
            theta1 = eur.GetTheta(sig, sim);


        } 
            else if (i.type == "Asian"){
                Asian asian = new Asian()
            {
                UnderlyingPrice = udl,
                YieldPoint = yp,
                Strike = i.Strike,
                T = i.T,
                Sigma = i.sigma,
                Iscall = i.Iscall,
                    
            };


            price = asian.GetPrice(asian.UnderlyingPrice.Price, asian.YieldPoint.Rate, asian.Sigma, asian.T, sig, sim);
            
            delta1 = asian.GetDelta(sig, sim);
            gamma1 = asian.GetGamma(sig, sim);
            rho1 = asian.GetRho(sig, sim);
            vega1 = asian.GetVega(sig, sim);
            theta1 = asian.GetTheta(sig, sim);
                

            }

            else if (i.type =="Barrier"){
                MC_CV.Barrier barrier = new MC_CV.Barrier()
            {
                UnderlyingPrice = udl,
                YieldPoint = yp,
                Strike =i.Strike,
                T = i.T,
                Sigma = i.sigma,
                Iscall = i.Iscall,
                bar = i.bar,
                UpOut = i.UpOut,
                UpIn = i.UpIn,
                DownIn = i.DownIn,
                DownOut = i.DownOut,
                    
            };


            price = barrier.GetPrice(barrier.UnderlyingPrice.Price, barrier.YieldPoint.Rate, barrier.Sigma, barrier.T, sig, sim);

            //CalValue(barrier, barrier.UnderlyingPrice.Price, barrier.YieldPoint.Rate, barrier.Sigma, barrier.T, sig, sim)
            
            delta1 = barrier.GetDelta(sig, sim);
            gamma1 = barrier.GetGamma(sig, sim);
            rho1 = barrier.GetRho(sig, sim);
            vega1 = barrier.GetVega(sig, sim);
            theta1 = barrier.GetTheta(sig, sim);


            }

            else if (i.type =="Digital"){
                Digital digital = new Digital()
            {
                UnderlyingPrice = udl,
                YieldPoint = yp,
                Strike = i.Strike,
                T = i.T,
                Sigma = i.sigma,
                Iscall = i.Iscall,
                rebate = i.rebate,
                    
            };


            price = digital.GetPrice(digital.UnderlyingPrice.Price, digital.YieldPoint.Rate, digital.Sigma, digital.T, sig, sim);
            
            delta1 = digital.GetDelta(sig, sim);
            gamma1 = digital.GetGamma(sig, sim);
            rho1 = digital.GetRho(sig, sim);
            vega1 = digital.GetVega(sig, sim);
            theta1 = digital.GetTheta(sig, sim);


            }

            else if (i.type == "Lookback"){
                Lookback look = new Lookback()
            {
                UnderlyingPrice = udl,
                YieldPoint = yp,
                Strike = i.Strike,
                T = i.T,
                Sigma = i.sigma,
                Iscall = i.Iscall,
                
                    
            };


            price = look.GetPrice(look.UnderlyingPrice.Price, look.YieldPoint.Rate, look.Sigma, look.T, sig, sim);
            
            delta1 = look.GetDelta(sig, sim);
            gamma1 = look.GetGamma(sig, sim);
            rho1 = look.GetRho(sig, sim);
            vega1 = look.GetVega(sig, sim);
            theta1 = look.GetTheta(sig, sim);


            }

            else if (i.type =="Range"){
                MC_CV.Range range = new MC_CV.Range()
            {
                UnderlyingPrice = udl,
                YieldPoint = yp,
                Strike = i.Strike,
                T = i.T,
                Sigma = i.sigma,
                Iscall = i.Iscall,
                
                    
            };


            price = range.GetPrice(range.UnderlyingPrice.Price, range.YieldPoint.Rate, range.Sigma, range.T, sig, sim);
            
            delta1 = range.GetDelta(sig, sim);
            gamma1 = range.GetGamma(sig, sim);
            rho1 = range.GetRho(sig, sim);
            vega1 = range.GetVega(sig, sim);
            theta1 = range.GetTheta(sig, sim);

            }
        
        return (Ok(new OutputResults()
        {

            // double[,] price = European.GetPrice(i.S, i.r,i.sigma, i.T, i.sig, sim),

            result = price[0,0],
            SE = price[0,1],
            delta = delta1,
            gamma = gamma1,
            vega = vega1,
            theta = theta1,
            rho = rho1,
            
        

           
        }));
    }
}

